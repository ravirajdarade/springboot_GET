package com.howtodoinjava.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.howtodoinjava.demo.model.Employee;

@Repository
public class EmployeeRepository {
	
	public List<Employee> getAllEmployees() 
    {
		List<Employee> employeesList = new ArrayList<Employee>();
		employeesList.add(new Employee(20,"Raviraj","Darade","ravirajdarade@gmail.com"));
		employeesList.add(new Employee(10,"Priyanka","Wagh","priyankawagh2010@gmail.com"));
		return employeesList;
    }

	public Employee getEmployees(Integer id) {
		List<Employee> employeesList = getAllEmployees();
		for(Employee e:employeesList) {
			if(e.getId()==id)
				return e;
		}
		return null;
	}

}
