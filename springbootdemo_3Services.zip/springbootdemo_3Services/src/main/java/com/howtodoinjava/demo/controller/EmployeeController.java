package com.howtodoinjava.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.howtodoinjava.demo.model.Employee;
import com.howtodoinjava.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/getAllEmployee")
    public List<Employee> getAllEmployees() 
    {
		List<Employee> employeeList = employeeService.getAllEmployees();
		return employeeList;
    }
	
	//path param example
	@GetMapping("/getEmployee/{id}")
    public Employee getEmployee(@PathVariable("id") Integer id) 
    {
		Employee employee = employeeService.getEmployees(id);
		return employee;
    }
	
	//query param example
	@GetMapping("/getEmp")
    public Employee getEmp(@RequestParam(name="id") Integer id) 
    {
		Employee employee = employeeService.getEmployees(id);
		return employee;
    }

}
